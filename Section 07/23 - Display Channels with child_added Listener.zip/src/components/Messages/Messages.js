import React from "react";

class Messages extends React.Component {
  render() {
    return <div>Messages</div>;
  }
}

export default Messages;
