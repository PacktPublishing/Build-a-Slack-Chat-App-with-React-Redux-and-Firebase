import React from "react";

class SidePanel extends React.Component {
  render() {
    return <div>SidePanel</div>;
  }
}

export default SidePanel;
