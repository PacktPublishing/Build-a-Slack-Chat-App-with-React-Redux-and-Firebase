import React from "react";

class ColorPanel extends React.Component {
  render() {
    return <div>ColorPanel</div>;
  }
}

export default ColorPanel;
